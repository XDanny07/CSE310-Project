import java.util.*;
public class Entry {
    
    public static void main(String[] args) {
        int choice;
        Scanner input = new Scanner(System.in);
        System.out.println("\n--------------------------------------------------------------------------------");
        System.out.println("                      *Hospital Management System Project*");
        System.out.println("--------------------------------------------------------------------------------");
      all:  
        while (true) {
            System.out.println("-----------------------------------*MAIN MENU*----------------------------------");
            System.out.println("1.Doctors\n2.Patients\n3.Medicines\n4.Nurses\n5.Records\n0.Exit\n");
            System.out.print("Enter Choice : ");
            choice = input.nextInt();


            switch (choice) {
                case 1:
                            Doctors doc = new Doctors();
                            int docmenu = 1;
                            while (docmenu!=0) {
                                System.out.println("\n-----------------------------------*DOCTOR MENU*----------------------------------");
                                System.out.println("1.List All Doctors\n0.Back\n");
                                System.out.print("Enter Choice : ");
                                docmenu = input.nextInt();
                                switch (docmenu) {
                                    case 1:
                                        doc.printdoctable();
                                        break;
                                
                                    default:
                                        break;
                                }
                            }
                            break;

                case 2:
                            Patients pat = new Patients();
                            int patmenu = 1;
                            while (patmenu!=0) {
                                System.out.println("\n-----------------------------------*PATIENT MENU*----------------------------------");
                                System.out.println("1.List All Patients\n0.Back\n");
                                System.out.print("Enter Choice : ");
                                patmenu = input.nextInt();
                                switch (patmenu) {
                                    case 1:
                                        pat.printpattable();
                                        break;
                                
                                    default:
                                        break;
                                }
                            }
                            break;
                case 3:                
                            Medicine med = new Medicine();
                            int medmenu = 1;
                            while (medmenu!=0) {
                                System.out.println("\n-----------------------------------*MEDICINES MENU*----------------------------------");
                                System.out.println("1.List Inventory\n2.Add Medicine\n3.Remove Medicine\n0.Back\n");
                                System.out.print("Enter Choice : ");
                                medmenu = input.nextInt();
                                switch (medmenu) {
                                    case 1:
                                        med.printMedicinetable();
                                        break;
                                    case 2:
                                        med.addMedicine();
                                        break;
                                    case 3:
                                        med.removeMedicine();
                                        break;
                                    default:
                                        break;
                                }
                            }
                            break;
                case 4:
                            Nurse nur = new Nurse();
                            int nurmenu = 1;
                            while (nurmenu!=0) {
                                System.out.println("\n-----------------------------------*NURSES MENU*----------------------------------");
                                System.out.println("1.List All Nurses\n2.Register Nurse\n3.Deregister Nurse\n0.Back\n");
                                System.out.print("Enter Choice : ");
                                nurmenu = input.nextInt();
                                switch (nurmenu) {
                                    case 1:
                                        nur.printnursetable();
                                        break;
                                    case 2:
                                        nur.addNurse();
                                        break;
                                    case 3:
                                        nur.removeNurse();
                                        break;
                                    default:
                                        break;
                                }
                            }
                            break;

                case 5:
                            int recmenu = 1;
                            while (recmenu!=0) {
                                System.out.println("\n-----------------------------------*RECORD MENU*----------------------------------");
                                System.out.println("1.Diagnosis\n2.Appointments\n0.Back\n");
                                System.out.print("Enter Choice : ");
                                recmenu = input.nextInt();
                                switch(recmenu){
                                    case 1:
                                            Diagnosis diag = new Diagnosis();
                                            
                                            int diagmenu = 1;
                                            while (diagmenu!=0) {
                                                System.out.println("\n-----------------------------------*DIAGNOSIS MENU*----------------------------------");
                                                System.out.println("1.Show Current Diagnosis\n0.Back\n");
                                                System.out.print("Enter Choice : ");
                                                diagmenu = input.nextInt();
                                                    switch (diagmenu) {
                                                        case 1:
                                                            diag.printDiagtable();
                                                            break;
                                                    
                                                        default:
                                                            break;
                                                    }
                                            }
                                            break;
                                    case 2:
                                            Appointment app = new Appointment();
                    
                                            int appmenu = 1;
                                            while (appmenu!=0) {
                                                System.out.println("\n-----------------------------------*APPOINTMENT MENU*----------------------------------");
                                                System.out.println("1.Show Appointments\n0.Back\n");
                                                System.out.print("Enter Choice : ");
                                                appmenu = input.nextInt();
                                                    switch (appmenu) {
                                                        case 1:
                                                            app.printAppointmenttable();
                                                            break;
                                                    
                                                        default:
                                                            break;
                                                    }
                                            }
                                            break;
                                        default:
                                            break;
                                }
                            }
                            break;
                default:
                    break all;
            }
        }
    }
}
