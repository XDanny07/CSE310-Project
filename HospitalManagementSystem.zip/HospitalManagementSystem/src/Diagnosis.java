import java.sql.*;
import com.google.gson.*;

public class Diagnosis {
    static Connection con;
    static Statement wand;


    public  static JsonObject gettable(){
        try{
            con = DBConnection.GetConnection();
            wand = DBConnection.GetWand(con);
            ResultSet rs = wand.executeQuery("select * from Diagnosis");
            JsonObject res = new JsonObject();
            System.out.println(res);
            int count = 1;
            while (rs.next()) {
                JsonObject temp = new JsonObject();
                temp.addProperty("diano",rs.getInt(1));
                temp.addProperty("issuedate",rs.getString(2));
                temp.addProperty("treatment", rs.getString(3));
                temp.addProperty("remarks", rs.getString(4));
                temp.addProperty("nid", rs.getString(5));
                temp.addProperty("did", rs.getString(6));
                res.add(""+count, temp);
                count++;
            }
            DBConnection.CloseConnection(con);
            return res;

        }catch(Exception e){
            System.out.println(e);
            DBConnection.CloseConnection(con);
            return null;
        }
    }

    public void printDiagtable(){
        JsonObject temp = Diagnosis.gettable();
        System.out.println(temp);
        System.out.print("---------------------------------------------------------------------------------------\n");
        System.out.printf("| %-2s | %-14s | %-18s | %-20s | %-8s | %-6s |%n", "ID","ISSUE DATE","TREATMENT","REMARKS","Nurse ID","DOC ID");
        System.out.print("---------------------------------------------------------------------------------------");
        System.out.println();
        for (int i = 1; i <= temp.size(); i++) {
            JsonObject doc = temp.getAsJsonObject().get(""+i).getAsJsonObject();
            int diano = doc.get("diano").getAsInt();
            String issuedate = doc.get("issuedate").getAsString();
            String treatment = doc.get("treatment").getAsString();
            String remarks = doc.get("remarks").getAsString();
            int nid = doc.get("nid").getAsInt();
            int did = doc.get("did").getAsInt();
            System.out.printf("| %-2s | %-14s | %-18s | %-20s | %-8s | %-6s |%n",diano,issuedate,treatment,remarks,nid,did);
        }
        System.out.print("---------------------------------------------------------------------------------------\n");
    }

    public void addDoctor(){

    }
    public static void main(String[] args){
        
        Diagnosis ob = new Diagnosis();
        ob.printDiagtable();
        

    }

    
}
