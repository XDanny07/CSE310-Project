import java.sql.*;

public class DBConnection{
    
    public static Connection GetConnection() {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitalms","root", "9191");
            return con;
        }catch(Exception e){
            System.out.println(e);
            return null;
        }
    }
    public static void CloseConnection(Connection ob) {
        try{
            ob.close();
        }catch(Exception e){
            System.out.println(e);
        }
    }
    public static Statement GetWand(Connection ob){
        try {
             return ob.createStatement();
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }

}