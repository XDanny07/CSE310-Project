import java.sql.*;
import com.google.gson.*;
import java.util.*;

public class Medicine {
    static Connection con;
    static Statement wand;


    public  static JsonObject gettable(){
        try{
            con = DBConnection.GetConnection();
            wand = DBConnection.GetWand(con);
            ResultSet rs = wand.executeQuery("select * from Medicine");
            JsonObject res = new JsonObject();
            int count = 1;
            while (rs.next()) {
                JsonObject temp = new JsonObject();
                temp.addProperty("regno",rs.getInt(1));
                temp.addProperty("medname",rs.getString(2));
                temp.addProperty("price", rs.getString(3));
                temp.addProperty("expdate", rs.getString(4));
                res.add(""+count, temp);
                count++;
            }
            DBConnection.CloseConnection(con);
            return res;

        }catch(Exception e){
            System.out.println(e);
            DBConnection.CloseConnection(con);
            return null;
        }
    }

    public void printMedicinetable(){
        JsonObject temp = Medicine.gettable();
        System.out.print("----------------------------------------------------------\n");
        System.out.printf("| %-8s | %-15s | %-10s | %-12s |%n", "Med ID","NAME","Price","Expiry");
        System.out.print("----------------------------------------------------------");
        System.out.println();
        for (int i = 1; i <= temp.size(); i++) {
            JsonObject doc = temp.getAsJsonObject().get(""+i).getAsJsonObject();
            int regno = doc.get("regno").getAsInt();
            String medname = doc.get("medname").getAsString();
            float price = doc.get("price").getAsFloat();
            String expdate = doc.get("expdate").getAsString();
            System.out.printf("| %-8s | %-15s | %-10s | %-12s |%n",regno,medname,price,expdate);
        }
        System.out.print("----------------------------------------------------------\n");
    }

    public void addMedicine(){
        Scanner input = new Scanner(System.in);
        con = DBConnection.GetConnection();
        wand = DBConnection.GetWand(con);
        try{
            ResultSet r = wand.executeQuery("select max(reg_no) from medicine");
            r.next();
            int at = r.getInt(1)+1;
            System.out.print("Enter Medicine Name : ");
            String name = input.nextLine();
            System.out.print("Enter Price : ");
            Float price = input.nextFloat();
            System.out.println("Exp Date in YYYY/MM/DD : ");
            String date = input.next();
            String query = String.format("insert into medicine values(%d,'%s',%.1f,'%s')",at,name,price,date);
            wand.executeUpdate(query);
            System.out.println("Added Succesfully");
        }catch(Exception e){
            System.out.println(e);
        }
        DBConnection.CloseConnection(con);
    }
    public void removeMedicine(){
        Scanner input = new Scanner(System.in);
        con = DBConnection.GetConnection();
        wand = DBConnection.GetWand(con);
        try{
            System.out.print("Enter ID Of The Medicine You Want to Delete : ");
            int id = input.nextInt();
            String query = String.format("delete from medicine where reg_no=%d",id);
            wand.executeUpdate(query);
            System.out.println("Removed");
        }catch(Exception e){
            System.out.println(e);
        }
        DBConnection.CloseConnection(con);
    }
    public static void main(String[] args){
        Medicine ob = new Medicine();
        ob.addMedicine();
        
    
    }

}
