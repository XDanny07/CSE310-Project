import java.sql.*;
import com.google.gson.*;

public class Patients {
    static Connection con;
    static Statement wand;

    public  static JsonObject gettable(){
        try{
            con = DBConnection.GetConnection();
            wand = DBConnection.GetWand(con);
            ResultSet rs = wand.executeQuery("select * from patients");
            JsonObject res = new JsonObject();
            int count = 1;
            while (rs.next()) {
                JsonObject temp = new JsonObject();
                temp.addProperty("ssn",rs.getInt(1));
                temp.addProperty("fname",rs.getString(2));
                temp.addProperty("lname", rs.getString(3));
                temp.addProperty("age", rs.getString(4));
                temp.addProperty("gender", rs.getString(5));
                temp.addProperty("nurseid", rs.getInt(6));
                temp.addProperty("recid", rs.getInt(7));
                res.add(""+count, temp);
                count++;
            }
            DBConnection.CloseConnection(con);
            return res;

        }catch(Exception e){
            System.out.println(e);
            DBConnection.CloseConnection(con);
            return null;
        }
    }

    public void printpattable(){
        JsonObject temp = Patients.gettable();
        System.out.print("-------------------------------------------------------------------------------\n");
        System.out.printf("| %-12s | %-10s | %-10s | %-5s | %-6s | %-8s | %-6s |%n", "SSN","FNAME","LNAME","AGE","GENDER","NURSE ID","REC ID");
        System.out.print("-------------------------------------------------------------------------------");
        System.out.println();
        for (int i = 1; i <= temp.size(); i++) {
            JsonObject doc = temp.getAsJsonObject().get(""+i).getAsJsonObject();
            int ssn = doc.get("ssn").getAsInt();
            String fname = doc.get("fname").getAsString();
            String lname = doc.get("lname").getAsString();
            int age = doc.get("age").getAsInt();
            String gender = doc.get("gender").getAsString();
            int nurseid = doc.get("nurseid").getAsInt();
            int recid = doc.get("recid").getAsInt();
            System.out.printf("| %-12s | %-10s | %-10s | %-5s | %-6s | %-8s | %-6s |%n",ssn,fname,lname,age,gender,nurseid,recid);
        }
        System.out.print("-------------------------------------------------------------------------------\n");
    }

    public void addDoctor(){

    }
    public static void main(String[] args){
        Patients ob = new Patients();
        ob.printpattable();
        
    
    }

}
