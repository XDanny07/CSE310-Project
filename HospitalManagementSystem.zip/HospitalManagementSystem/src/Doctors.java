import java.sql.*;
import com.google.gson.*;

public class Doctors {
    static Connection con;
    static Statement wand;

 

    public  static JsonObject gettable(){
        try{
            con = DBConnection.GetConnection();
            wand = DBConnection.GetWand(con);
            ResultSet rs = wand.executeQuery("select * from doctors");
            JsonObject res = new JsonObject();
            int count = 1;
            while (rs.next()) {
                JsonObject temp = new JsonObject();
                temp.addProperty("did",rs.getInt(1));
                temp.addProperty("dname",rs.getString(2));
                temp.addProperty("gender", rs.getString(3));
                temp.addProperty("qual", rs.getString(4));
                temp.addProperty("spec", rs.getString(5));
                temp.addProperty("free", rs.getString(6));
                res.add(""+count, temp);
                count++;
            }
            DBConnection.CloseConnection(con);
            return res;

        }catch(Exception e){
            System.out.println(e);
            DBConnection.CloseConnection(con);
            return null;
        }
    }

    public void printdoctable(){
        JsonObject temp = Doctors.gettable();
        System.out.print("---------------------------------------------------------------------------------------------\n");
        System.out.printf("| %-2s | %-18s | %-8s | %-20s | %-20s | %-6s |%n", "ID","DNAME","GENDER","QUALIFICATION","SPECIFICATION","FREE");
        System.out.print("---------------------------------------------------------------------------------------------");
        System.out.println();
        for (int i = 1; i <= temp.size(); i++) {
            JsonObject doc = temp.getAsJsonObject().get(""+i).getAsJsonObject();
            int did = doc.get("did").getAsInt();
            String dname = doc.get("dname").getAsString();
            String gender = doc.get("gender").getAsString();
            String qual = doc.get("qual").getAsString();
            String spec = doc.get("spec").getAsString();
            String free = doc.get("free").getAsString();
            System.out.printf("| %-2s | %-18s | %-8s | %-20s | %-20s | %-6s |%n",did,dname,gender,qual,spec,free);
        }
        System.out.print("---------------------------------------------------------------------------------------------\n");
    }

    public void addDoctor(){

    }
    public static void main(String[] args){
        

    }

    
}
