import java.sql.*;
import com.google.gson.*;

public class Appointment {
    static Connection con;
    static Statement wand;

 

    public  static JsonObject gettable(){
        try{
            con = DBConnection.GetConnection();
            wand = DBConnection.GetWand(con);
            ResultSet rs = wand.executeQuery("select * from Appointment");
            JsonObject res = new JsonObject();
            int count = 1;
            while (rs.next()) {
                JsonObject temp = new JsonObject();
                temp.addProperty("aid",rs.getInt(1));
                temp.addProperty("adate",rs.getString(2));
                temp.addProperty("atime", rs.getString(3));
                temp.addProperty("recid", rs.getString(4));
                res.add(""+count, temp);
                count++;
            }
            DBConnection.CloseConnection(con);
            return res;

        }catch(Exception e){
            System.out.println(e);
            DBConnection.CloseConnection(con);
            return null;
        }
    }

    public void printAppointmenttable(){
        JsonObject temp = Appointment.gettable();
        System.out.print("----------------------------------------------------\n");
        System.out.printf("| %-14s | %-10s | %-9s | %-6s |%n", "Appointment ID","DATE","TIME","REC ID");
        System.out.print("----------------------------------------------------");
        System.out.println();
        for (int i = 1; i <= temp.size(); i++) {
            JsonObject doc = temp.getAsJsonObject().get(""+i).getAsJsonObject();
            int aid = doc.get("aid").getAsInt();
            String adate = doc.get("adate").getAsString();
            String atime = doc.get("atime").getAsString();
            int recid = doc.get("recid").getAsInt();
            System.out.printf("| %-14s | %-10s | %-9s | %-6s |%n",aid,adate,atime,recid);
        }
        System.out.print("----------------------------------------------------\n");
    }

    public void addDoctor(){

    }
    public static void main(String[] args){
        Appointment ob = new Appointment();
        ob.printAppointmenttable();
        
    
    }

}
