import java.sql.*;
import com.google.gson.*;
import java.util.*;

public class Nurse {
    static Connection con;
    static Statement wand;

    public  static JsonObject gettable(){
        try{
            con = DBConnection.GetConnection();
            wand = DBConnection.GetWand(con);
            con = DBConnection.GetConnection();
            wand = DBConnection.GetWand(con);
            ResultSet rs = wand.executeQuery("select * from Nurse");
            JsonObject res = new JsonObject();
            int count = 1;
            while (rs.next()) {
                JsonObject temp = new JsonObject();
                temp.addProperty("nid",rs.getInt(1));
                temp.addProperty("fname",rs.getString(2));
                temp.addProperty("gender", rs.getString(3));
                temp.addProperty("did", rs.getString(4));
                res.add(""+count, temp);
                count++;
            }
            DBConnection.CloseConnection(con);
            return res;

        }catch(Exception e){
            System.out.println(e);
            DBConnection.CloseConnection(con);
            return null;
        }
    }

    public void printnursetable(){
        JsonObject temp = Nurse.gettable();
        System.out.print("-----------------------------------------------\n");
        System.out.printf("| %-8s | %-10s | %-10s | %-6s |%n", "NURSE ID","NAME","GENDER","DOC ID");
        System.out.print("-----------------------------------------------");
        System.out.println();
        for (int i = 1; i <= temp.size(); i++) {
            JsonObject doc = temp.getAsJsonObject().get(""+i).getAsJsonObject();
            int nid = doc.get("nid").getAsInt();
            String fname = doc.get("fname").getAsString();
            String gender = doc.get("gender").getAsString();
            int did = doc.get("did").getAsInt();
            System.out.printf("| %-8s | %-10s | %-10s | %-6s |%n",nid,fname,gender,did);
        }
        System.out.print("-----------------------------------------------\n");
    }

    public void addNurse(){
        Scanner input = new Scanner(System.in);
        con = DBConnection.GetConnection();
        wand = DBConnection.GetWand(con);
        try{
            ResultSet r = wand.executeQuery("select max(nurse_id) from nurse");
            r.next();
            int at = r.getInt(1)+1;
            System.out.print("Enter Name : ");
            String name = input.nextLine();
            System.out.print("Enter Gender (F/M) : ");
            char gender = input.next().charAt(0);
            System.out.print("Assigned To Doctor With ID : ");
            int did = input.nextInt();
            String query = String.format("insert into nurse values(%d,'%s','%c',%d)",at,name,gender,did);
            wand.executeUpdate(query);
            System.out.println("Registered Succesfully");
        }catch(Exception e){
            System.out.println(e);
        }
        DBConnection.CloseConnection(con);
    }
    public void removeNurse(){
        Scanner input = new Scanner(System.in);
        con = DBConnection.GetConnection();
        wand = DBConnection.GetWand(con);
        try{
            System.out.print("Enter ID Of The Nurse :");
            int id = input.nextInt();
            String query = String.format("delete from nurse where nurse_id=%d",id);
            wand.executeUpdate(query);
            System.out.println("Deregistered");
        }catch(Exception e){
            System.out.println(e);
        }
        DBConnection.CloseConnection(con);
    }
    public static void main(String[] args){
        Nurse ob = new Nurse();
        ob.printnursetable(); 
    }

}
